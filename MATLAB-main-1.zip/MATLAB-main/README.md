# MATLAB

syms x

a = sym(1/2);

f = exp(-a*x^2);


fplot(f)
